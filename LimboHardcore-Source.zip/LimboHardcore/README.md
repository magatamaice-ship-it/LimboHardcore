# LimboHardcore

Plugin for Paper/Spigot Minecraft 1.21.x. A player who dies is sent to the shared `Limbo` world for 15 minutes, then returned to the main world's spawn. The deadline is stored as a timestamp in `plugins/LimboHardcore/penalties.yml`, so offline time and server restarts count toward the 15 minutes.

## Requirements
- Paper recommended (Minecraft 1.21.x)
- Java 21
- GitHub repository for the automatic build workflow

## Build with GitHub Actions
1. Create a GitHub repository, e.g. `LimboHardcore`.
2. Upload/push all files from this project, preserving `.github/workflows/build.yml`.
3. Open the repository's **Actions** tab and select **Build LimboHardcore**.
4. Wait for the workflow to finish successfully (green check).
5. Open the completed workflow run, scroll to **Artifacts**, and download `LimboHardcore-JAR`.
6. Extract the ZIP and take `LimboHardcore.jar`.

## Install
1. Stop the Minecraft server.
2. Put `LimboHardcore.jar` in the server's `plugins` folder.
3. Start the server. The plugin creates/loads a world named `Limbo` automatically.
4. Stop the server and edit `plugins/LimboHardcore/config.yml` if needed.
5. Start the server again. The default penalty is 900 seconds (15 minutes).

## Commands
- `/limbo status` — show plugin status and number of players with an active penalty.
- `/limbo release <player>` — release an online player from Limbo (OP by default).
- `/limbo reload` — reload config values; restart the server to fully apply world/spawn changes.

## Important notes
- The return world defaults to the first loaded world other than `Limbo`; set `return-world` in config if your main world has a different name.
- By default, the return location is that world's spawn. Set `return-spawn.use-world-spawn: false` to use custom coordinates.
- `limbo-spawn` defaults to coordinates `0.5, 80, 0.5`. Make sure this is a safe area and build a platform there, or change the coordinates before players use the plugin.
- Players can meet in Limbo. PvP is allowed by default; set `prevent-pvp-in-limbo: true` to disable player-vs-player damage there.
- This plugin does not itself create custom terrain or a dramatic Limbo build; it creates a separate vanilla world. Build the Limbo environment at the configured spawn.
- Test on a backup/test server before using it on a live world. Other plugins that forcibly teleport players may need compatibility testing.
