package id.server.limbohardcore;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class LimboHardcore extends JavaPlugin implements Listener {
    private final Map<UUID, Long> penalties = new HashMap<>();
    private final Map<UUID, Long> lastActionBarSecond = new HashMap<>();
    private final Map<UUID, Long> authorizedTeleport = new HashMap<>();
    private File penaltiesFile;
    private YamlConfiguration penaltiesConfig;
    private World limboWorld;
    private BukkitTask ticker;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        penaltiesFile = new File(getDataFolder(), "penalties.yml");
        loadPenalties();
        limboWorld = loadOrCreateLimboWorld();
        if (limboWorld == null) {
            getLogger().severe("Could not create/load Limbo world. Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        getServer().getPluginManager().registerEvents(this, this);
        ticker = Bukkit.getScheduler().runTaskTimer(this, this::tickPenalties, 20L, 20L);
        // Recover players who were online during a /reload or plugin enable.
        for (Player player : Bukkit.getOnlinePlayers()) {
            enforcePenaltyOnJoin(player);
        }
        getLogger().info("LimboHardcore enabled. Limbo world: " + limboWorld.getName());
    }

    @Override
    public void onDisable() {
        if (ticker != null) ticker.cancel();
        savePenalties();
    }

    private World loadOrCreateLimboWorld() {
        String name = getConfig().getString("limbo-world", "Limbo");
        World world = Bukkit.getWorld(name);
        if (world == null) {
            WorldCreator creator = new WorldCreator(name);
            creator.environment(World.Environment.NORMAL);
            world = Bukkit.createWorld(creator);
        }
        if (world != null) {
            world.setAutoSave(true);
            world.setKeepSpawnInMemory(true);
            Location spawn = configuredLocation(world, "limbo-spawn", world.getSpawnLocation());
            world.setSpawnLocation(spawn);
            // Build a small safe platform so players do not fall when the world is first created.
            int centerX = spawn.getBlockX();
            int centerY = spawn.getBlockY();
            int centerZ = spawn.getBlockZ();
            for (int x = centerX - 7; x <= centerX + 7; x++) {
                for (int z = centerZ - 7; z <= centerZ + 7; z++) {
                    world.getBlockAt(x, centerY - 1, z).setType(Material.DEEPSLATE_BRICKS, false);
                    world.getBlockAt(x, centerY, z).setType(Material.AIR, false);
                    world.getBlockAt(x, centerY + 1, z).setType(Material.AIR, false);
                }
            }
            world.getBlockAt(centerX - 6, centerY, centerZ - 6).setType(Material.SOUL_LANTERN, false);
            world.getBlockAt(centerX + 6, centerY, centerZ - 6).setType(Material.SOUL_LANTERN, false);
            world.getBlockAt(centerX - 6, centerY, centerZ + 6).setType(Material.SOUL_LANTERN, false);
            world.getBlockAt(centerX + 6, centerY, centerZ + 6).setType(Material.SOUL_LANTERN, false);
        }
        return world;
    }

    private Location configuredLocation(World world, String path, Location fallback) {
        double x = getConfig().getDouble(path + ".x", fallback.getX());
        double y = getConfig().getDouble(path + ".y", fallback.getY());
        double z = getConfig().getDouble(path + ".z", fallback.getZ());
        float yaw = (float) getConfig().getDouble(path + ".yaw", fallback.getYaw());
        float pitch = (float) getConfig().getDouble(path + ".pitch", fallback.getPitch());
        return new Location(world, x, y, z, yaw, pitch);
    }

    private World getReturnWorld() {
        String configured = getConfig().getString("return-world", "");
        if (configured != null && !configured.isBlank()) {
            World world = Bukkit.getWorld(configured);
            if (world != null) return world;
            getLogger().warning("Configured return-world '" + configured + "' is not loaded; using first loaded world.");
        }
        for (World world : Bukkit.getWorlds()) {
            if (!world.getName().equalsIgnoreCase(getConfig().getString("limbo-world", "Limbo"))) return world;
        }
        return Bukkit.getWorlds().isEmpty() ? null : Bukkit.getWorlds().get(0);
    }

    private Location getReturnLocation() {
        World world = getReturnWorld();
        if (world == null) return null;
        if (getConfig().getBoolean("return-spawn.use-world-spawn", true)) return world.getSpawnLocation();
        return configuredLocation(world, "return-spawn", world.getSpawnLocation());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        UUID id = event.getEntity().getUniqueId();
        // A death inside Limbo must not restart the timer.
        if (!penalties.containsKey(id)) {
            long duration = Math.max(1L, getConfig().getLong("penalty-seconds", 900L));
            penalties.put(id, System.currentTimeMillis() + duration * 1000L);
            savePenalties();
            event.getEntity().sendMessage(ChatColor.DARK_PURPLE + "Kamu telah memasuki Limbo. Waktu: 15 menit.");
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onRespawn(PlayerRespawnEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        if (penalties.containsKey(id)) {
            event.setRespawnLocation(limboWorld.getSpawnLocation());
            Bukkit.getScheduler().runTask(this, () -> {
                Player player = event.getPlayer();
                if (player.isOnline() && penalties.containsKey(id)) {
                    teleportAuthorized(player, limboWorld.getSpawnLocation());
                    showRemaining(player, true);
                }
            });
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        // Wait one tick so the player's normal join location is fully established.
        Bukkit.getScheduler().runTask(this, () -> enforcePenaltyOnJoin(event.getPlayer()));
    }

    private void enforcePenaltyOnJoin(Player player) {
        if (!player.isOnline()) return;
        Long expires = penalties.get(player.getUniqueId());
        if (expires == null) return;
        if (expires <= System.currentTimeMillis()) {
            releasePlayer(player, true);
        } else {
            teleportAuthorized(player, limboWorld.getSpawnLocation());
            showRemaining(player, true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onTeleport(PlayerTeleportEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        Long expires = penalties.get(id);
        if (expires == null) return;
        if (expires <= System.currentTimeMillis()) {
            // The ticker will release them; allow only plugin-authorized destinations until then.
            if (!isAuthorized(id)) event.setCancelled(true);
            return;
        }
        if (isAuthorized(id)) return;
        if (event.getTo() == null || !event.getTo().getWorld().equals(limboWorld)) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(ChatColor.RED + "Kamu tidak bisa keluar dari Limbo sebelum waktunya habis.");
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPortal(PlayerPortalEvent event) {
        if (penalties.containsKey(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onChangedWorld(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        if (penalties.containsKey(player.getUniqueId()) && !player.getWorld().equals(limboWorld)) {
            Bukkit.getScheduler().runTask(this, () -> {
                if (player.isOnline() && penalties.containsKey(player.getUniqueId())) {
                    teleportAuthorized(player, limboWorld.getSpawnLocation());
                }
            });
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        lastActionBarSecond.remove(event.getPlayer().getUniqueId());
        authorizedTeleport.remove(event.getPlayer().getUniqueId());
        savePenalties();
    }

    @EventHandler
    public void onLimboPvP(EntityDamageByEntityEvent event) {
        if (!getConfig().getBoolean("prevent-pvp-in-limbo", false)) return;
        if (event.getEntity() instanceof Player victim && victim.getWorld().equals(limboWorld)
                && event.getDamager() instanceof Player) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCommands(PlayerCommandPreprocessEvent event) {
        // Commands are not blocked globally; teleport attempts are caught by PlayerTeleportEvent.
        // This allows ordinary chat and harmless commands while in Limbo.
    }

    private void tickPenalties() {
        long now = System.currentTimeMillis();
        boolean changed = false;
        for (Map.Entry<UUID, Long> entry : new HashMap<>(penalties).entrySet()) {
            UUID id = entry.getKey();
            long expires = entry.getValue();
            Player player = Bukkit.getPlayer(id);
            if (expires <= now) {
                if (player != null && player.isOnline()) releasePlayer(player, false);
                else {
                    penalties.remove(id);
                    changed = true;
                }
            } else if (player != null && player.isOnline()) {
                if (!player.getWorld().equals(limboWorld)) teleportAuthorized(player, limboWorld.getSpawnLocation());
                showRemaining(player, false);
            }
        }
        if (changed) savePenalties();
    }

    private void showRemaining(Player player, boolean chatMessage) {
        Long expires = penalties.get(player.getUniqueId());
        if (expires == null) return;
        long seconds = Math.max(0L, (expires - System.currentTimeMillis() + 999L) / 1000L);
        long minutes = seconds / 60L;
        long remainder = seconds % 60L;
        String message = ChatColor.LIGHT_PURPLE + "Limbo " + ChatColor.GRAY + "| Terlahir kembali dalam "
                + ChatColor.WHITE + String.format("%02d:%02d", minutes, remainder);
        player.sendActionBar(message);
        if (chatMessage) player.sendMessage(message);
    }

    private void releasePlayer(Player player, boolean joiningAfterExpiry) {
        UUID id = player.getUniqueId();
        penalties.remove(id);
        lastActionBarSecond.remove(id);
        savePenalties();
        Location destination = getReturnLocation();
        if (destination != null) teleportAuthorized(player, destination);
        player.sendTitle(ChatColor.GREEN + "TERLAHIR KEMBALI", ChatColor.GRAY + "Kamu telah kembali ke dunia utama", 10, 60, 20);
        player.sendMessage(ChatColor.GREEN + "Waktu Limbo selesai. Kamu telah terlahir kembali!");
    }

    private void teleportAuthorized(Player player, Location destination) {
        UUID id = player.getUniqueId();
        authorizedTeleport.put(id, System.currentTimeMillis() + 3000L);
        player.teleport(destination, PlayerTeleportEvent.TeleportCause.PLUGIN);
    }

    private boolean isAuthorized(UUID id) {
        Long until = authorizedTeleport.get(id);
        if (until == null) return false;
        if (until < System.currentTimeMillis()) {
            authorizedTeleport.remove(id);
            return false;
        }
        return true;
    }

    private void loadPenalties() {
        if (!getDataFolder().exists() && !getDataFolder().mkdirs()) {
            getLogger().warning("Could not create plugin data directory.");
        }
        penaltiesConfig = YamlConfiguration.loadConfiguration(penaltiesFile);
        ConfigurationSection section = penaltiesConfig.getConfigurationSection("penalties");
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                long expires = section.getLong(key, 0L);
                if (expires > 0L) penalties.put(id, expires);
            } catch (IllegalArgumentException ex) {
                getLogger().warning("Ignoring invalid UUID in penalties.yml: " + key);
            }
        }
    }

    private void savePenalties() {
        if (penaltiesFile == null) return;
        YamlConfiguration yaml = new YamlConfiguration();
        for (Map.Entry<UUID, Long> entry : penalties.entrySet()) {
            yaml.set("penalties." + entry.getKey(), entry.getValue());
        }
        try {
            yaml.save(penaltiesFile);
        } catch (IOException ex) {
            getLogger().severe("Could not save penalties.yml: " + ex.getMessage());
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("limbo")) return false;
        if (!sender.hasPermission("limbo.admin")) {
            sender.sendMessage(ChatColor.RED + "Kamu tidak memiliki izin untuk perintah ini.");
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("status")) {
            sender.sendMessage(ChatColor.LIGHT_PURPLE + "LimboHardcore aktif. Pemain dalam Limbo: " + penalties.size());
            sender.sendMessage(ChatColor.GRAY + "Dunia Limbo: " + limboWorld.getName());
            return true;
        }
        if (args[0].equalsIgnoreCase("release") && args.length >= 2) {
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Pemain harus online agar bisa dilepaskan.");
                return true;
            }
            if (!penalties.containsKey(target.getUniqueId())) {
                sender.sendMessage(ChatColor.YELLOW + "Pemain tersebut tidak sedang menjalani hukuman Limbo.");
                return true;
            }
            releasePlayer(target, false);
            sender.sendMessage(ChatColor.GREEN + target.getName() + " telah dilepaskan dari Limbo.");
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            sender.sendMessage(ChatColor.GREEN + "Config dimuat ulang. Perubahan dunia/spawn berlaku penuh setelah restart server.");
            return true;
        }
        sender.sendMessage(ChatColor.YELLOW + "Gunakan: /limbo status | /limbo release <pemain> | /limbo reload");
        return true;
    }
}
